import Image from 'next/image'
import Link from 'next/link'
import { Pencil, Plus } from 'lucide-react'
import { AdminPageHeading } from '@/components/admin-page-heading'
import { menuItemsCollection } from '@/lib/collections'
import { money } from '@/lib/format'

export const dynamic = 'force-dynamic'

export default async function AdminMenuPage() {
  const menu = await menuItemsCollection()
  const items = await menu.find({}).sort({ name: 1 }).toArray()

  return (
    <>
      <AdminPageHeading
        title="Menu items"
        description="Manage dishes, pricing, categories and availability."
        action={
          <Link href="/admin/menu/new" className="inline-flex items-center gap-2 rounded-full bg-cta px-5 py-2.5 text-sm font-semibold text-cta-foreground">
            <Plus size={16} /> Add item
          </Link>
        }
      />
      {items.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          No menu items yet. Add your first dish to get started.
        </p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <div key={item.id} className="overflow-hidden rounded-2xl border border-border bg-card">
              <div className="relative aspect-[16/10]">
                <Image src={item.image} alt={item.name} fill className="object-cover" />
                {!item.isAvailable && (
                  <span className="absolute left-3 top-3 rounded-full bg-destructive px-3 py-1 text-[10px] font-semibold text-destructive-foreground">Unavailable</span>
                )}
              </div>
              <div className="p-4">
                <p className="text-xs uppercase tracking-wider text-primary">{item.category}</p>
                <div className="mt-1 flex items-center justify-between gap-2">
                  <h3 className="font-serif text-lg leading-tight">{item.name}</h3>
                  <span className="shrink-0 text-sm font-semibold">{money(item.price)}</span>
                </div>
                <Link
                  href={`/admin/menu/${item.id}/edit`}
                  className="mt-3 inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold hover:bg-secondary"
                >
                  <Pencil size={13} /> Edit item
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  )
}
